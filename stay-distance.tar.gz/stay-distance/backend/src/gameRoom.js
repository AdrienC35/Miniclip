const HorseAI = require('./horseAI');

// Constantes de gameplay (basées sur l'analyse du SWF)
const GAME_CONFIG = {
  RACE_DISTANCE: 1000, // Distance totale de la course
  BASE_SPEED: 3,
  MAX_SPEED: 12,
  BOOST_AMOUNT: 4,
  ENDURANCE_COST_PER_BOOST: 2,
  FATIGUE_THRESHOLD: 20,
  FATIGUE_SPEED_PENALTY: 0.5,
  TIMING_WINDOW: 500, // ms - fenêtre de timing parfait
  PERFECT_TIMING_BONUS: 1.5,
  EARLY_LATE_PENALTY: 0.7,
  ENDURANCE_REGEN_RATE: 0.5, // par seconde sans boost
  FRICTION: 0.95, // Décélération naturelle
  AI_COUNT: 5 // 5 chevaux IA + 1 joueur
};

class GameRoom {
  constructor(roomId, hostSocketId, hostName, maxPlayers) {
    this.roomId = roomId;
    this.hostId = hostSocketId;
    this.maxPlayers = maxPlayers;
    this.status = 'waiting'; // 'waiting', 'racing', 'finished'
    this.createdAt = Date.now();
    
    // Joueurs
    this.players = [{
      socketId: hostSocketId,
      name: hostName,
      horseId: 0,
      isReady: false
    }];
    
    // État de la course
    this.horses = [];
    this.raceStartTime = null;
    this.lastTickTime = null;
    this.winners = [];
  }

  addPlayer(socketId, playerName) {
    const horseId = this.players.length;
    this.players.push({
      socketId,
      name: playerName,
      horseId,
      isReady: false
    });
  }

  removePlayer(socketId) {
    this.players = this.players.filter(p => p.socketId !== socketId);
    
    // Si l'hôte part, donner le rôle au premier joueur restant
    if (this.hostId === socketId && this.players.length > 0) {
      this.hostId = this.players[0].socketId;
    }
  }

  startRace() {
    this.status = 'racing';
    this.raceStartTime = Date.now();
    this.lastTickTime = this.raceStartTime;
    this.winners = [];
    
    // Initialiser les chevaux
    this.horses = [];
    
    // Chevaux des joueurs
    this.players.forEach((player, index) => {
      this.horses.push({
        id: index,
        name: player.name,
        isPlayer: true,
        socketId: player.socketId,
        position: 0,
        speed: GAME_CONFIG.BASE_SPEED,
        endurance: 100,
        isFatigued: false,
        lastInputTime: 0,
        timingQuality: 'none', // 'perfect', 'good', 'early', 'late'
        finished: false,
        finishTime: null,
        rank: null,
        color: this.getHorseColor(index)
      });
    });
    
    // Ajouter les chevaux IA
    for (let i = this.players.length; i < 6; i++) {
      this.horses.push({
        id: i,
        name: `Cheval ${i + 1}`,
        isPlayer: false,
        ai: new HorseAI(i),
        position: 0,
        speed: GAME_CONFIG.BASE_SPEED,
        endurance: 100,
        isFatigued: false,
        lastInputTime: 0,
        timingQuality: 'none',
        finished: false,
        finishTime: null,
        rank: null,
        color: this.getHorseColor(i)
      });
    }
  }

  handlePlayerInput(socketId, timestamp) {
    const horse = this.horses.find(h => h.socketId === socketId);
    if (!horse || horse.finished) return;
    
    this.applyBoost(horse, timestamp);
  }

  applyBoost(horse, timestamp) {
    const now = Date.now();
    const timeSinceLastInput = now - horse.lastInputTime;
    
    // Vérifier si le timing est bon (rythme optimal)
    let timingQuality;
    let speedMultiplier;
    
    if (timeSinceLastInput < 300) {
      // Trop tôt - pénalité
      timingQuality = 'early';
      speedMultiplier = GAME_CONFIG.EARLY_LATE_PENALTY;
    } else if (timeSinceLastInput >= 300 && timeSinceLastInput <= 800) {
      // Timing parfait
      timingQuality = 'perfect';
      speedMultiplier = GAME_CONFIG.PERFECT_TIMING_BONUS;
    } else if (timeSinceLastInput > 800 && timeSinceLastInput <= 1200) {
      // Bon timing
      timingQuality = 'good';
      speedMultiplier = 1.0;
    } else {
      // Trop tard - pénalité
      timingQuality = 'late';
      speedMultiplier = GAME_CONFIG.EARLY_LATE_PENALTY;
    }
    
    horse.timingQuality = timingQuality;
    horse.lastInputTime = now;
    
    // Appliquer le boost
    if (horse.endurance > 0) {
      horse.speed = Math.min(
        GAME_CONFIG.MAX_SPEED,
        horse.speed + (GAME_CONFIG.BOOST_AMOUNT * speedMultiplier)
      );
      
      // Coût en endurance
      horse.endurance = Math.max(0, horse.endurance - GAME_CONFIG.ENDURANCE_COST_PER_BOOST);
      
      // Vérifier la fatigue
      if (horse.endurance < GAME_CONFIG.FATIGUE_THRESHOLD) {
        horse.isFatigued = true;
      }
    }
  }

  update(deltaTime) {
    if (this.status !== 'racing') return;
    
    const dt = deltaTime / 1000; // Convertir en secondes
    
    this.horses.forEach(horse => {
      if (horse.finished) return;
      
      // IA fait ses inputs
      if (!horse.isPlayer && horse.ai) {
        if (horse.ai.shouldBoost(horse, Date.now())) {
          this.applyBoost(horse, Date.now());
        }
      }
      
      // Appliquer la fatigue
      if (horse.isFatigued) {
        horse.speed *= GAME_CONFIG.FATIGUE_SPEED_PENALTY;
      }
      
      // Friction (décélération naturelle)
      horse.speed *= GAME_CONFIG.FRICTION;
      horse.speed = Math.max(GAME_CONFIG.BASE_SPEED, horse.speed);
      
      // Régénération d'endurance si pas de boost récent
      const timeSinceLastBoost = Date.now() - horse.lastInputTime;
      if (timeSinceLastBoost > 1000) {
        horse.endurance = Math.min(100, horse.endurance + GAME_CONFIG.ENDURANCE_REGEN_RATE * dt);
        
        if (horse.endurance > GAME_CONFIG.FATIGUE_THRESHOLD) {
          horse.isFatigued = false;
        }
      }
      
      // Mettre à jour la position
      horse.position += horse.speed * dt;
      
      // Vérifier si le cheval a terminé
      if (horse.position >= GAME_CONFIG.RACE_DISTANCE) {
        horse.position = GAME_CONFIG.RACE_DISTANCE;
        horse.finished = true;
        horse.finishTime = Date.now() - this.raceStartTime;
        
        // Attribuer le rang
        const finishedCount = this.horses.filter(h => h.finished).length;
        horse.rank = finishedCount;
        
        this.winners.push({
          horseId: horse.id,
          name: horse.name,
          time: horse.finishTime,
          rank: horse.rank
        });
      }
    });
  }

  isRaceFinished() {
    return this.horses.every(h => h.finished);
  }

  finishRace() {
    this.status = 'finished';
    
    // Trier les gagnants par temps
    this.winners.sort((a, b) => a.time - b.time);
  }

  getRaceState() {
    return {
      roomId: this.roomId,
      status: this.status,
      horses: this.horses.map(h => ({
        id: h.id,
        name: h.name,
        position: h.position,
        speed: h.speed,
        endurance: h.endurance,
        isFatigued: h.isFatigued,
        timingQuality: h.timingQuality,
        finished: h.finished,
        rank: h.rank,
        color: h.color
      })),
      raceTime: Date.now() - this.raceStartTime
    };
  }

  getFinalResults() {
    return {
      roomId: this.roomId,
      winners: this.winners,
      finalState: this.getRaceState()
    };
  }

  getPublicData() {
    return {
      roomId: this.roomId,
      hostName: this.players.find(p => p.socketId === this.hostId)?.name,
      playerCount: this.players.length,
      maxPlayers: this.maxPlayers,
      status: this.status,
      players: this.players.map(p => ({
        name: p.name,
        isHost: p.socketId === this.hostId
      }))
    };
  }

  getHorseColor(index) {
    const colors = [
      '#8B4513', // Brown
      '#000000', // Black
      '#808080', // Grey
      '#FFFFFF', // White
      '#D2691E', // Chestnut
      '#F4A460'  // Sandy
    ];
    return colors[index % colors.length];
  }
}

module.exports = GameRoom;
