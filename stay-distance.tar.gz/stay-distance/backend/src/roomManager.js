const { v4: uuidv4 } = require('uuid');
const GameRoom = require('./gameRoom');

class RoomManager {
  constructor() {
    this.rooms = new Map();
    this.playerRoomMap = new Map(); // socketId -> roomId
  }

  createRoom(hostSocketId, hostName, maxPlayers = 4) {
    const roomId = this.generateRoomId();
    const room = new GameRoom(roomId, hostSocketId, hostName, maxPlayers);
    
    this.rooms.set(roomId, room);
    this.playerRoomMap.set(hostSocketId, roomId);
    
    return room;
  }

  joinRoom(roomId, socketId, playerName) {
    const room = this.rooms.get(roomId);
    
    if (!room) {
      return { success: false, error: 'Room introuvable' };
    }
    
    if (room.status !== 'waiting') {
      return { success: false, error: 'La course a déjà commencé' };
    }
    
    if (room.players.length >= room.maxPlayers) {
      return { success: false, error: 'Room pleine' };
    }
    
    room.addPlayer(socketId, playerName);
    this.playerRoomMap.set(socketId, roomId);
    
    return { success: true, room };
  }

  leaveRoom(roomId, socketId) {
    const room = this.rooms.get(roomId);
    
    if (!room) {
      return { success: false, error: 'Room introuvable' };
    }
    
    room.removePlayer(socketId);
    this.playerRoomMap.delete(socketId);
    
    // Si la room est vide ou si l'hôte est parti, supprimer la room
    if (room.players.length === 0 || room.hostId === socketId) {
      this.rooms.delete(roomId);
      return { success: true, roomDeleted: true };
    }
    
    return { success: true, room };
  }

  getRoom(roomId) {
    return this.rooms.get(roomId);
  }

  getPlayerRooms(socketId) {
    const roomId = this.playerRoomMap.get(socketId);
    return roomId ? [roomId] : [];
  }

  getRoomCount() {
    return this.rooms.size;
  }

  getPublicRooms() {
    const publicRooms = [];
    
    this.rooms.forEach(room => {
      if (room.status === 'waiting') {
        publicRooms.push(room.getPublicData());
      }
    });
    
    return publicRooms;
  }

  cleanupEmptyRooms() {
    const roomsToDelete = [];
    
    this.rooms.forEach((room, roomId) => {
      if (room.players.length === 0) {
        roomsToDelete.push(roomId);
      }
    });
    
    roomsToDelete.forEach(roomId => {
      this.rooms.delete(roomId);
      console.log(`Room ${roomId} nettoyée (vide depuis trop longtemps)`);
    });
  }

  generateRoomId() {
    // Générer un ID court et lisible (6 caractères)
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  }
}

module.exports = RoomManager;
