const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const RoomManager = require('./roomManager');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Room Manager
const roomManager = new RoomManager();

// Routes REST
app.get('/health', (req, res) => {
  res.json({ status: 'ok', rooms: roomManager.getRoomCount() });
});

app.get('/rooms', (req, res) => {
  res.json(roomManager.getPublicRooms());
});

// WebSocket Events
io.on('connection', (socket) => {
  console.log(`[${new Date().toISOString()}] Client connecté: ${socket.id}`);

  // Créer une room
  socket.on('create_room', (data, callback) => {
    const { playerName, maxPlayers = 4 } = data;
    const room = roomManager.createRoom(socket.id, playerName, maxPlayers);
    
    socket.join(room.roomId);
    
    callback({ 
      success: true, 
      room: room.getPublicData() 
    });
    
    console.log(`Room créée: ${room.roomId} par ${playerName}`);
  });

  // Rejoindre une room
  socket.on('join_room', (data, callback) => {
    const { roomId, playerName } = data;
    
    const result = roomManager.joinRoom(roomId, socket.id, playerName);
    
    if (result.success) {
      socket.join(roomId);
      
      // Notifier tous les joueurs de la room
      io.to(roomId).emit('room_updated', result.room.getPublicData());
      
      callback({ success: true, room: result.room.getPublicData() });
      console.log(`${playerName} a rejoint room ${roomId}`);
    } else {
      callback({ success: false, error: result.error });
    }
  });

  // Quitter une room
  socket.on('leave_room', (data) => {
    const { roomId } = data;
    handleLeaveRoom(socket.id, roomId);
  });

  // Démarrer la course
  socket.on('start_race', (data, callback) => {
    const { roomId } = data;
    const room = roomManager.getRoom(roomId);
    
    if (!room) {
      callback({ success: false, error: 'Room introuvable' });
      return;
    }
    
    if (room.hostId !== socket.id) {
      callback({ success: false, error: 'Seul l\'hôte peut démarrer' });
      return;
    }
    
    if (room.players.length < 1) {
      callback({ success: false, error: 'Pas assez de joueurs' });
      return;
    }
    
    room.startRace();
    
    // Envoyer le state initial à tous
    io.to(roomId).emit('race_started', room.getRaceState());
    
    callback({ success: true });
    console.log(`Course démarrée dans room ${roomId}`);
  });

  // Input joueur (clic pour booster)
  socket.on('player_input', (data) => {
    const { roomId, timestamp } = data;
    const room = roomManager.getRoom(roomId);
    
    if (!room || room.status !== 'racing') return;
    
    room.handlePlayerInput(socket.id, timestamp);
    
    // Broadcast le nouvel état
    io.to(roomId).emit('game_state_update', room.getRaceState());
  });

  // Mise à jour du jeu (tick)
  socket.on('game_tick', (data) => {
    const { roomId, deltaTime } = data;
    const room = roomManager.getRoom(roomId);
    
    if (!room || room.status !== 'racing') return;
    
    room.update(deltaTime);
    
    // Si la course est terminée
    if (room.isRaceFinished()) {
      room.finishRace();
      io.to(roomId).emit('race_finished', room.getFinalResults());
    } else {
      io.to(roomId).emit('game_state_update', room.getRaceState());
    }
  });

  // Déconnexion
  socket.on('disconnect', () => {
    console.log(`Client déconnecté: ${socket.id}`);
    
    // Trouver et quitter toutes les rooms du joueur
    const playerRooms = roomManager.getPlayerRooms(socket.id);
    playerRooms.forEach(roomId => {
      handleLeaveRoom(socket.id, roomId);
    });
  });
});

// Fonction helper pour gérer le départ d'un joueur
function handleLeaveRoom(socketId, roomId) {
  const result = roomManager.leaveRoom(roomId, socketId);
  
  if (result.success) {
    if (result.roomDeleted) {
      console.log(`Room ${roomId} supprimée (vide)`);
    } else {
      // Notifier les autres joueurs
      io.to(roomId).emit('room_updated', result.room.getPublicData());
      console.log(`Joueur ${socketId} a quitté room ${roomId}`);
    }
  }
}

// Nettoyage périodique des rooms vides
setInterval(() => {
  roomManager.cleanupEmptyRooms();
}, 60000); // Toutes les minutes

// Lancer le serveur
server.listen(PORT, () => {
  console.log(`🏇 Serveur Stay The Distance lancé sur le port ${PORT}`);
  console.log(`WebSocket prêt à accepter des connexions`);
});
