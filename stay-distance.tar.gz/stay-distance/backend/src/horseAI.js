class HorseAI {
  constructor(horseId) {
    this.horseId = horseId;
    this.lastBoostTime = 0;
    
    // Chaque IA a des caractéristiques différentes
    this.difficulty = this.getDifficulty(horseId);
    this.aggressiveness = 0.4 + Math.random() * 0.4; // 0.4-0.8
    this.consistencyOffset = (Math.random() - 0.5) * 100; // -50 à +50ms
  }

  getDifficulty(horseId) {
    // Les IAs ont des difficultés graduelles
    const difficulties = [
      { timing: 600, variance: 200, conservatism: 0.8 },  // Facile
      { timing: 550, variance: 150, conservatism: 0.7 },  // Moyen-Facile
      { timing: 500, variance: 100, conservatism: 0.6 },  // Moyen
      { timing: 450, variance: 80, conservatism: 0.5 },   // Moyen-Difficile
      { timing: 400, variance: 50, conservatism: 0.4 }    // Difficile
    ];
    
    return difficulties[horseId % difficulties.length];
  }

  shouldBoost(horse, currentTime) {
    const timeSinceLastBoost = currentTime - this.lastBoostTime;
    
    // Calculer le timing idéal avec variance
    const idealTiming = this.difficulty.timing + 
                        (Math.random() - 0.5) * this.difficulty.variance +
                        this.consistencyOffset;
    
    // Décision de boost basée sur plusieurs facteurs
    
    // 1. Timing de base
    if (timeSinceLastBoost < idealTiming) {
      return false;
    }
    
    // 2. Gestion de l'endurance (l'IA est conservatrice quand l'endurance est basse)
    const enduranceThreshold = 30 + (this.difficulty.conservatism * 40);
    if (horse.endurance < enduranceThreshold) {
      // L'IA est plus prudente - boost moins souvent
      const conservativeBoostChance = horse.endurance / enduranceThreshold;
      if (Math.random() > conservativeBoostChance) {
        return false;
      }
    }
    
    // 3. Agressivité en fin de course
    const raceProgress = horse.position / 1000; // 0 à 1
    if (raceProgress > 0.7) {
      // En fin de course, l'IA booste plus si elle a de l'endurance
      if (horse.endurance > 50 && Math.random() < this.aggressiveness) {
        this.lastBoostTime = currentTime;
        return true;
      }
    }
    
    // 4. Si fatigué, être plus prudent
    if (horse.isFatigued) {
      if (Math.random() > 0.3) { // 70% de chance de ne pas booster si fatigué
        return false;
      }
    }
    
    // 5. Décision finale
    this.lastBoostTime = currentTime;
    return true;
  }

  // Stratégie d'endurance : l'IA ajuste son comportement selon la course
  getEnduranceStrategy(raceProgress, currentEndurance) {
    if (raceProgress < 0.3) {
      // Début : conservateur
      return currentEndurance > 60 ? 'normal' : 'conservative';
    } else if (raceProgress < 0.7) {
      // Milieu : équilibré
      return currentEndurance > 40 ? 'normal' : 'conservative';
    } else {
      // Fin : agressif si de l'endurance reste
      return currentEndurance > 20 ? 'aggressive' : 'survival';
    }
  }
}

module.exports = HorseAI;
