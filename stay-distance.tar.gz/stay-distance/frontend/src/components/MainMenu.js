import React, { useState } from 'react';
import './MainMenu.css';

function MainMenu({ onCreateRoom, onJoinRoom, isConnected }) {
  const [playerName, setPlayerName] = useState('');
  const [roomId, setRoomId] = useState('');
  const [showJoinForm, setShowJoinForm] = useState(false);

  const handleCreate = (e) => {
    e.preventDefault();
    if (playerName.trim() && isConnected) {
      onCreateRoom(playerName.trim());
    }
  };

  const handleJoin = (e) => {
    e.preventDefault();
    if (playerName.trim() && roomId.trim() && isConnected) {
      onJoinRoom(playerName.trim(), roomId.trim().toUpperCase());
    }
  };

  return (
    <div className="main-menu">
      <div className="menu-container">
        <h1 className="game-title">
          <span className="horse-icon">🐴</span>
          Stay The Distance
          <span className="horse-icon">🏁</span>
        </h1>
        
        <p className="game-subtitle">Course de chevaux multijoueur</p>
        
        {!isConnected && (
          <div className="connection-warning">
            ⚠️ Connexion au serveur en cours...
          </div>
        )}
        
        {!showJoinForm ? (
          <form onSubmit={handleCreate} className="menu-form">
            <input
              type="text"
              placeholder="Votre nom"
              value={playerName}
              onChange={(e) => setPlayerName(e.target.value)}
              maxLength={20}
              className="input-field"
              autoFocus
            />
            
            <button 
              type="submit" 
              className="btn btn-primary"
              disabled={!isConnected || !playerName.trim()}
            >
              🎮 Créer une partie
            </button>
            
            <button 
              type="button"
              onClick={() => setShowJoinForm(true)}
              className="btn btn-secondary"
              disabled={!isConnected}
            >
              🚪 Rejoindre une partie
            </button>
          </form>
        ) : (
          <form onSubmit={handleJoin} className="menu-form">
            <input
              type="text"
              placeholder="Votre nom"
              value={playerName}
              onChange={(e) => setPlayerName(e.target.value)}
              maxLength={20}
              className="input-field"
            />
            
            <input
              type="text"
              placeholder="Code de la room (ex: ABC123)"
              value={roomId}
              onChange={(e) => setRoomId(e.target.value.toUpperCase())}
              maxLength={6}
              className="input-field"
              autoFocus
            />
            
            <button 
              type="submit" 
              className="btn btn-primary"
              disabled={!isConnected || !playerName.trim() || !roomId.trim()}
            >
              ✅ Rejoindre
            </button>
            
            <button 
              type="button"
              onClick={() => {
                setShowJoinForm(false);
                setRoomId('');
              }}
              className="btn btn-secondary"
            >
              ← Retour
            </button>
          </form>
        )}
        
        <div className="game-info">
          <p>🎯 Objectif : Gérez le timing de vos boosts pour gagner !</p>
          <p>⚡ Boost parfait = vitesse maximale</p>
          <p>💪 Attention à votre endurance</p>
        </div>
      </div>
    </div>
  );
}

export default MainMenu;
