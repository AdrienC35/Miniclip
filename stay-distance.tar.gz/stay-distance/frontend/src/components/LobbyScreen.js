import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getSocket } from '../services/socketService';
import './LobbyScreen.css';

function LobbyScreen({ room, playerName, onLeave, onStart }) {
  const navigate = useNavigate();
  
  useEffect(() => {
    const socket = getSocket();
    
    socket.on('race_started', () => {
      navigate('/game');
    });
    
    return () => {
      socket.off('race_started');
    };
  }, [navigate]);
  
  const isHost = room.players && room.players[0]?.name === playerName;
  const canStart = room.players && room.players.length >= 1;
  
  return (
    <div className="lobby-screen">
      <div className="lobby-container">
        <h1 className="lobby-title">🏇 Salle d'attente</h1>
        
        <div className="room-code-box">
          <p className="room-code-label">Code de la room :</p>
          <p className="room-code">{room.roomId}</p>
          <p className="room-code-hint">Partagez ce code avec vos amis !</p>
        </div>
        
        <div className="players-section">
          <h2 className="players-title">
            Joueurs ({room.players?.length || 0} / {room.maxPlayers})
          </h2>
          
          <ul className="players-list">
            {room.players && room.players.map((player, index) => (
              <li key={index} className="player-item">
                <span className="player-name">
                  {player.name}
                  {player.isHost && <span className="host-badge">👑 Hôte</span>}
                  {player.name === playerName && <span className="you-badge">Vous</span>}
                </span>
              </li>
            ))}
          </ul>
        </div>
        
        <div className="lobby-actions">
          {isHost ? (
            <button 
              className="btn btn-primary btn-large"
              onClick={onStart}
              disabled={!canStart}
            >
              {canStart ? '🏁 Démarrer la course' : '⏳ En attente de joueurs...'}
            </button>
          ) : (
            <div className="waiting-message">
              ⏳ En attente que l'hôte démarre la course...
            </div>
          )}
          
          <button 
            className="btn btn-secondary"
            onClick={() => {
              onLeave();
              navigate('/');
            }}
          >
            ← Quitter la room
          </button>
        </div>
        
        <div className="game-instructions">
          <h3>🎮 Comment jouer</h3>
          <ul>
            <li>Cliquez / Appuyez pour booster votre cheval</li>
            <li>Trouvez le bon rythme pour maximiser votre vitesse</li>
            <li>Gérez votre endurance, ne la gaspillez pas !</li>
            <li>Si vous êtes fatigué, laissez votre endurance se régénérer</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default LobbyScreen;
