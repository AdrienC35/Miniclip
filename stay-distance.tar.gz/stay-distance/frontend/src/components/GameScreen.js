import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Phaser from 'phaser';
import { getSocket } from '../services/socketService';
import './GameScreen.css';

// Import de la scène de jeu
import RaceScene from '../game/RaceScene';

function GameScreen({ room, playerName, onExit }) {
  const gameRef = useRef(null);
  const gameInstanceRef = useRef(null);
  const navigate = useNavigate();
  const [isFinished, setIsFinished] = useState(false);
  const [winners, setWinners] = useState([]);
  
  useEffect(() => {
    // Configuration Phaser
    const config = {
      type: Phaser.AUTO,
      parent: gameRef.current,
      width: 1200,
      height: 600,
      backgroundColor: '#87CEEB',
      physics: {
        default: 'arcade',
        arcade: {
          debug: false
        }
      },
      scene: [RaceScene],
      scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH
      }
    };
    
    // Créer l'instance Phaser
    const game = new Phaser.Game(config);
    gameInstanceRef.current = game;
    
    // Passer les données au jeu
    game.registry.set('roomId', room.roomId);
    game.registry.set('playerName', playerName);
    
    // Écouter les événements WebSocket
    const socket = getSocket();
    
    socket.on('game_state_update', (gameState) => {
      game.events.emit('server_update', gameState);
    });
    
    socket.on('race_finished', (results) => {
      console.log('Course terminée !', results);
      setIsFinished(true);
      setWinners(results.winners);
      game.events.emit('race_finished', results);
    });
    
    // Cleanup
    return () => {
      socket.off('game_state_update');
      socket.off('race_finished');
      
      if (gameInstanceRef.current) {
        gameInstanceRef.current.destroy(true);
      }
    };
  }, [room.roomId, playerName]);
  
  const handleBackToMenu = () => {
    onExit();
    navigate('/');
  };
  
  return (
    <div className="game-screen">
      <div ref={gameRef} className="game-container" />
      
      {isFinished && (
        <div className="results-overlay">
          <div className="results-box">
            <h1 className="results-title">🏁 Course terminée !</h1>
            
            <div className="podium">
              {winners.slice(0, 3).map((winner, index) => (
                <div key={winner.horseId} className={`podium-place place-${index + 1}`}>
                  <div className="place-medal">
                    {index === 0 && '🥇'}
                    {index === 1 && '🥈'}
                    {index === 2 && '🥉'}
                  </div>
                  <div className="place-name">{winner.name}</div>
                  <div className="place-time">
                    {(winner.time / 1000).toFixed(2)}s
                  </div>
                </div>
              ))}
            </div>
            
            {winners.length > 3 && (
              <div className="other-results">
                <h3>Autres résultats</h3>
                <ul>
                  {winners.slice(3).map((winner) => (
                    <li key={winner.horseId}>
                      {winner.rank}. {winner.name} - {(winner.time / 1000).toFixed(2)}s
                    </li>
                  ))}
                </ul>
              </div>
            )}
            
            <button 
              className="btn btn-primary btn-large"
              onClick={handleBackToMenu}
            >
              🏠 Retour au menu
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default GameScreen;
