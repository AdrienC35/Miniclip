import io from 'socket.io-client';

let socket = null;

export const initSocket = () => {
  if (socket) return socket;
  
  const WS_URL = process.env.REACT_APP_WS_URL || 'http://localhost:3001';
  
  socket = io(WS_URL, {
    transports: ['websocket', 'polling'],
    reconnection: true,
    reconnectionDelay: 1000,
    reconnectionAttempts: 5
  });
  
  socket.on('connect_error', (error) => {
    console.error('Erreur de connexion:', error.message);
  });
  
  return socket;
};

export const getSocket = () => {
  if (!socket) {
    throw new Error('Socket non initialisé. Appelez initSocket() d\'abord.');
  }
  return socket;
};

export const disconnectSocket = () => {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
};
