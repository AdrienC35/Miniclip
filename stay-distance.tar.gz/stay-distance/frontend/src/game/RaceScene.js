import Phaser from 'phaser';
import { getSocket } from '../services/socketService';

class RaceScene extends Phaser.Scene {
  constructor() {
    super({ key: 'RaceScene' });
    
    this.horses = [];
    this.raceStarted = false;
    this.raceFinished = false;
    this.roomId = null;
    this.playerName = null;
    this.lastTickTime = 0;
    this.playerHorse = null;
  }

  init() {
    this.roomId = this.registry.get('roomId');
    this.playerName = this.registry.get('playerName');
  }

  preload() {
    // Pas de chargement d'assets externes pour l'instant
    // On va dessiner les chevaux programmatiquement
  }

  create() {
    // Fond - ciel
    const sky = this.add.rectangle(600, 100, 1200, 200, 0x87CEEB);
    
    // Piste - herbe
    const grass = this.add.rectangle(600, 400, 1200, 400, 0x90EE90);
    
    // Ligne de départ
    this.add.rectangle(50, 300, 10, 400, 0xFFFFFF);
    this.add.text(60, 250, 'DÉPART', { 
      fontSize: '20px', 
      color: '#fff',
      backgroundColor: '#000',
      padding: { x: 10, y: 5 }
    });
    
    // Ligne d'arrivée
    this.add.rectangle(1150, 300, 10, 400, 0xFF0000);
    this.add.text(1060, 250, 'ARRIVÉE', { 
      fontSize: '20px', 
      color: '#fff',
      backgroundColor: '#ff0000',
      padding: { x: 10, y: 5 }
    });
    
    // Titre
    this.add.text(600, 50, '🏇 Stay The Distance 🏁', {
      fontSize: '32px',
      color: '#fff',
      fontStyle: 'bold',
      stroke: '#000',
      strokeThickness: 4
    }).setOrigin(0.5);
    
    // Instructions
    this.instructionText = this.add.text(600, 550, 'CLIQUEZ POUR BOOSTER ! Trouvez le bon rythme !', {
      fontSize: '20px',
      color: '#fff',
      backgroundColor: '#000',
      padding: { x: 20, y: 10 }
    }).setOrigin(0.5);
    
    // Écouter les mises à jour du serveur
    this.game.events.on('server_update', this.handleServerUpdate, this);
    this.game.events.on('race_finished', this.handleRaceFinished, this);
    
    // Input tactile et souris
    this.input.on('pointerdown', this.handleInput, this);
    
    // Démarrer le ticker
    this.lastTickTime = Date.now();
    this.time.addEvent({
      delay: 16, // 60 FPS
      callback: this.gameTick,
      callbackScope: this,
      loop: true
    });
  }

  handleServerUpdate(gameState) {
    if (!gameState || !gameState.horses) return;
    
    // Si première mise à jour, créer les chevaux
    if (this.horses.length === 0) {
      this.createHorses(gameState.horses);
    }
    
    // Mettre à jour les chevaux
    gameState.horses.forEach((serverHorse, index) => {
      if (this.horses[index]) {
        this.updateHorseVisual(this.horses[index], serverHorse);
      }
    });
  }

  createHorses(serverHorses) {
    const startX = 80;
    const startY = 200;
    const spacing = 60;
    
    serverHorses.forEach((serverHorse, index) => {
      const y = startY + (index * spacing);
      
      // Créer le container du cheval
      const horseContainer = this.add.container(startX, y);
      
      // Corps du cheval (rectangle pour placeholder)
      const body = this.add.rectangle(0, 0, 50, 30, parseInt(serverHorse.color.replace('#', '0x')));
      body.setStrokeStyle(2, 0x000000);
      
      // Tête
      const head = this.add.circle(25, -5, 10, parseInt(serverHorse.color.replace('#', '0x')));
      head.setStrokeStyle(2, 0x000000);
      
      // Numéro
      const number = this.add.text(0, 0, (index + 1).toString(), {
        fontSize: '20px',
        color: '#fff',
        fontStyle: 'bold'
      }).setOrigin(0.5);
      
      horseContainer.add([body, head, number]);
      
      // Nom et stats
      const nameText = this.add.text(startX, y - 35, serverHorse.name, {
        fontSize: '14px',
        color: '#000',
        backgroundColor: '#fff',
        padding: { x: 5, y: 2 }
      });
      
      const statsText = this.add.text(startX, y + 25, '', {
        fontSize: '12px',
        color: '#000',
        backgroundColor: 'rgba(255,255,255,0.8)',
        padding: { x: 5, y: 2 }
      });
      
      // Barre d'endurance
      const enduranceBar = this.add.graphics();
      
      // Feedback visuel du timing
      const timingFeedback = this.add.text(startX + 70, y, '', {
        fontSize: '16px',
        fontStyle: 'bold'
      });
      
      this.horses.push({
        id: serverHorse.id,
        container: horseContainer,
        nameText,
        statsText,
        enduranceBar,
        timingFeedback,
        data: serverHorse
      });
      
      // Marquer le cheval du joueur
      if (serverHorse.name === this.playerName) {
        this.playerHorse = this.horses[this.horses.length - 1];
        nameText.setBackgroundColor('#FFD700');
        nameText.setColor('#000');
      }
    });
    
    this.raceStarted = true;
  }

  updateHorseVisual(horse, serverData) {
    // Mettre à jour la position (convertir position de jeu en position écran)
    const maxDistance = 1000;
    const maxScreenX = 1150;
    const minScreenX = 80;
    const screenX = minScreenX + (serverData.position / maxDistance) * (maxScreenX - minScreenX);
    
    horse.container.x = screenX;
    
    // Mettre à jour les stats
    const speed = serverData.speed.toFixed(1);
    const endurance = Math.round(serverData.endurance);
    horse.statsText.setText(`Speed: ${speed} | Endurance: ${endurance}%`);
    
    // Barre d'endurance
    const barWidth = 50;
    const barHeight = 5;
    const barX = horse.container.x;
    const barY = horse.container.y + 20;
    
    horse.enduranceBar.clear();
    horse.enduranceBar.fillStyle(0x333333);
    horse.enduranceBar.fillRect(barX - 25, barY, barWidth, barHeight);
    
    let enduranceColor = 0x00FF00; // Vert
    if (serverData.endurance < 50) enduranceColor = 0xFFFF00; // Jaune
    if (serverData.endurance < 20) enduranceColor = 0xFF0000; // Rouge
    
    horse.enduranceBar.fillStyle(enduranceColor);
    horse.enduranceBar.fillRect(barX - 25, barY, barWidth * (serverData.endurance / 100), barHeight);
    
    // Feedback de timing
    if (serverData.timingQuality !== 'none') {
      let feedbackText = '';
      let feedbackColor = '#fff';
      
      switch (serverData.timingQuality) {
        case 'perfect':
          feedbackText = '⚡ PARFAIT !';
          feedbackColor = '#FFD700';
          break;
        case 'good':
          feedbackText = '✓ Bien';
          feedbackColor = '#00FF00';
          break;
        case 'early':
          feedbackText = 'Trop tôt';
          feedbackColor = '#FF9800';
          break;
        case 'late':
          feedbackText = 'Trop tard';
          feedbackColor = '#FF9800';
          break;
      }
      
      horse.timingFeedback.setText(feedbackText);
      horse.timingFeedback.setColor(feedbackColor);
      horse.timingFeedback.setPosition(horse.container.x + 30, horse.container.y - 15);
      
      // Effacer après 500ms
      this.time.delayedCall(500, () => {
        horse.timingFeedback.setText('');
      });
    }
    
    // Animation de fatigue
    if (serverData.isFatigued) {
      horse.container.setAlpha(0.7);
    } else {
      horse.container.setAlpha(1.0);
    }
    
    // Marquer si terminé
    if (serverData.finished && serverData.rank) {
      horse.nameText.setText(`${serverData.name} - #${serverData.rank}`);
    }
    
    horse.data = serverData;
  }

  handleInput() {
    if (!this.raceStarted || this.raceFinished) return;
    
    const socket = getSocket();
    socket.emit('player_input', {
      roomId: this.roomId,
      timestamp: Date.now()
    });
  }

  gameTick() {
    if (!this.raceStarted || this.raceFinished) return;
    
    const now = Date.now();
    const deltaTime = now - this.lastTickTime;
    this.lastTickTime = now;
    
    // Envoyer un tick au serveur
    const socket = getSocket();
    socket.emit('game_tick', {
      roomId: this.roomId,
      deltaTime
    });
  }

  handleRaceFinished(results) {
    this.raceFinished = true;
    this.instructionText.setText('🏁 COURSE TERMINÉE !');
    console.log('Résultats:', results);
  }

  shutdown() {
    this.game.events.off('server_update', this.handleServerUpdate, this);
    this.game.events.off('race_finished', this.handleRaceFinished, this);
  }
}

export default RaceScene;
