import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import './App.css';
import MainMenu from './components/MainMenu';
import GameScreen from './components/GameScreen';
import LobbyScreen from './components/LobbyScreen';
import { initSocket, getSocket } from './services/socketService';

function App() {
  const [playerName, setPlayerName] = useState('');
  const [currentRoom, setCurrentRoom] = useState(null);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    // Initialiser la connexion WebSocket
    const socket = initSocket();
    
    socket.on('connect', () => {
      console.log('✅ Connecté au serveur');
      setIsConnected(true);
    });
    
    socket.on('disconnect', () => {
      console.log('❌ Déconnecté du serveur');
      setIsConnected(false);
    });
    
    socket.on('room_updated', (roomData) => {
      console.log('Room mise à jour:', roomData);
      setCurrentRoom(roomData);
    });
    
    return () => {
      socket.off('connect');
      socket.off('disconnect');
      socket.off('room_updated');
    };
  }, []);

  const handleCreateRoom = (name) => {
    setPlayerName(name);
    
    const socket = getSocket();
    socket.emit('create_room', { playerName: name, maxPlayers: 6 }, (response) => {
      if (response.success) {
        setCurrentRoom(response.room);
      } else {
        alert('Erreur lors de la création de la room');
      }
    });
  };

  const handleJoinRoom = (name, roomId) => {
    setPlayerName(name);
    
    const socket = getSocket();
    socket.emit('join_room', { roomId, playerName: name }, (response) => {
      if (response.success) {
        setCurrentRoom(response.room);
      } else {
        alert(`Impossible de rejoindre: ${response.error}`);
      }
    });
  };

  const handleLeaveRoom = () => {
    if (!currentRoom) return;
    
    const socket = getSocket();
    socket.emit('leave_room', { roomId: currentRoom.roomId });
    setCurrentRoom(null);
  };

  const handleStartGame = () => {
    if (!currentRoom) return;
    
    const socket = getSocket();
    socket.emit('start_race', { roomId: currentRoom.roomId }, (response) => {
      if (!response.success) {
        alert(`Impossible de démarrer: ${response.error}`);
      }
    });
  };

  return (
    <Router>
      <div className="App">
        <Routes>
          <Route 
            path="/" 
            element={
              <MainMenu 
                onCreateRoom={handleCreateRoom}
                onJoinRoom={handleJoinRoom}
                isConnected={isConnected}
              />
            } 
          />
          
          <Route 
            path="/lobby" 
            element={
              currentRoom ? (
                <LobbyScreen 
                  room={currentRoom}
                  playerName={playerName}
                  onLeave={handleLeaveRoom}
                  onStart={handleStartGame}
                />
              ) : (
                <Navigate to="/" replace />
              )
            } 
          />
          
          <Route 
            path="/game" 
            element={
              currentRoom ? (
                <GameScreen 
                  room={currentRoom}
                  playerName={playerName}
                  onExit={handleLeaveRoom}
                />
              ) : (
                <Navigate to="/" replace />
              )
            } 
          />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
