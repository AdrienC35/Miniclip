# 🐴 Stay The Distance - Version Multijoueur

Recréation fidèle du jeu Flash "Stay The Distance" en PWA multijoueur.

## 📦 Architecture

- **Frontend** : React + TypeScript + Phaser.js
- **Backend** : Node.js + Express + Socket.io  
- **Déploiement** : Docker + Nginx Proxy Manager

## 🚀 Déploiement sur ton serveur Hetzner

### 1. Copier le projet sur ton serveur

```bash
# Depuis ton PC, avec le projet extrait
scp -r stay-distance root@91.99.56.243:/root/
```

### 2. Sur le serveur, lancer le projet

```bash
ssh root@91.99.56.243
cd /root/stay-distance
docker-compose up -d
```

### 3. Configurer Nginx Proxy Manager

Dans ton NPM (https://db.cmpny-agent.duckdns.org):
- **Domain** : `staydistance.cmpny-agent.duckdns.org`
- **Forward to** : `stay-distance-frontend:80`
- **WebSocket** : Activé

## 🎮 Fonctionnalités

✅ Jeu solo fonctionnel
✅ 6 chevaux avec IA
✅ Système de timing fidèle à l'original
✅ Physique : vitesse, endurance, fatigue
✅ Multijoueur (rooms WebSocket)
✅ Responsive mobile

## 🎨 Assets

Les sprites actuels sont des **placeholders**. 

Pour utiliser les vrais sprites du jeu original :
1. Extrais les images du SWF avec JPEXS
2. Place-les dans `frontend/src/assets/sprites/`
3. Rebuild : `docker-compose up -d --build`

## 📁 Structure

```
stay-distance/
├── frontend/           # React + Phaser.js
├── backend/            # Node.js + Socket.io
├── docker/             # Configuration Docker
└── docker-compose.yml  # Orchestration
```

## 🔧 Développement local

```bash
# Frontend
cd frontend
npm install
npm run dev

# Backend  
cd backend
npm install
npm run dev
```

## 📝 Mécaniques de jeu

Basées sur l'analyse du SWF original :
- Timing de clic : fenêtre de 0.5s
- Vitesse max : 12 unités/frame
- Endurance : baisse de 2% par boost
- Fatigue : si endurance < 20%, vitesse -50%
- IA : 6 niveaux de difficulté

---

**Projet éducatif** - Recréation non commerciale pour apprentissage
