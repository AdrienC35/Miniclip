# Stay The Distance Online — Rooms + Receiver + Controller

## Démarrage local
```bash
npm install
npm start
# ouvrir http://localhost:3000/receiver-tv.html
# ouvrir http://localhost:3000/controller.html
```
- Entrez le **room code** identique sur le receiver et chaque contrôleur.
- Receiver affiche la course vue aérienne.
- Contrôleurs pilotent leur cheval: Gauche/Droite, Saut, Cravache, Pace±.

## Déploiement Hetzner (résumé)
```bash
# sur le serveur
sudo apt update && sudo apt install -y nodejs npm
git clone <votre-repo>
cd stay-the-distance-online
npm install
npm start    # ou pm2 start server.js --name horses
```
Placez Nginx en reverse proxy vers `127.0.0.1:3000` et activez SSL Let’s Encrypt.
