import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.static('public'));

const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: '*' } });

// --- Game model ---
const TICK_HZ = 30;
const TRACK_LEN = 1000; // arbitrary units
const LANES = 4;

const rooms = new Map(); // roomCode -> { status, players: Map<socketId, Player>, createdAt }
function ensureRoom(code) {
  if (!rooms.has(code)) {
    rooms.set(code, { status: 'lobby', players: new Map(), createdAt: Date.now(), startAt: null });
  }
  return rooms.get(code);
}

function newPlayer(name) {
  return {
    name,
    lane: 1,
    x: 0,
    v: 0,
    stamina: 100,
    whipsLeft: 3,
    pace: 0,            // -2..+2
    jumping: false,     // command one-shot
    finished: false,
    finishTime: null
  };
}

// --- Networking ---
io.on('connection', (socket) => {
  let joinedRoom = null;

  socket.on('join', ({ room, role, name }) => {
    if (!room || !role) return;
    const r = ensureRoom(room);
    socket.join(room);
    joinedRoom = room;

    if (role === 'controller') {
      const player = newPlayer(name || socket.id.slice(0,4));
      r.players.set(socket.id, player);
      io.to(room).emit('lobby', lobbyState(r));
    } else if (role === 'receiver') {
      // receiver only joins to listen
      io.to(room).emit('lobby', lobbyState(r));
    }
  });

  socket.on('start', () => {
    if (!joinedRoom) return;
    const r = rooms.get(joinedRoom);
    if (!r) return;
    if (r.status !== 'lobby') return;
    r.status = 'running';
    r.startAt = Date.now();
    for (const p of r.players.values()) {
      p.x = 0; p.v = 0; p.stamina = 100; p.whipsLeft = 3; p.pace = 0; p.finished = false; p.finishTime = null;
    }
    io.to(joinedRoom).emit('started', {});
  });

  socket.on('input', (input) => {
    if (!joinedRoom) return;
    const r = rooms.get(joinedRoom); if (!r) return;
    const p = r.players.get(socket.id); if (!p) return;

    // input: { left,right,jump,whip,paceDelta }
    if (input.left)  p.lane = Math.max(0, p.lane - 1);
    if (input.right) p.lane = Math.min(LANES - 1, p.lane + 1);
    if (input.jump)  p.jumping = true;
    if (input.whip && p.whipsLeft > 0) { p.whipsLeft -= 1; p.stamina = Math.max(0, p.stamina - 8); p.v += 2.0; }
    if (typeof input.paceDelta === 'number') {
      p.pace = Math.max(-2, Math.min(2, p.pace + input.paceDelta));
    }
  });

  socket.on('leave', () => onDisconnect());
  socket.on('disconnect', () => onDisconnect());

  function onDisconnect() {
    if (!joinedRoom) return;
    const r = rooms.get(joinedRoom);
    if (r) {
      r.players.delete(socket.id);
      if (r.players.size === 0) {
        rooms.delete(joinedRoom);
      } else {
        io.to(joinedRoom).emit('lobby', lobbyState(r));
      }
    }
    joinedRoom = null;
  }
});

function lobbyState(r) {
  return {
    status: r.status,
    players: [...r.players.entries()].map(([id, p]) => ({
      id,
      name: p.name,
    })),
  };
}

// --- Game loop (authoritative) ---
setInterval(() => {
  for (const [code, r] of rooms) {
    if (r.status !== 'running') continue;

    let allFinished = true;
    for (const [id, p] of r.players) {
      if (p.finished) continue;
      allFinished = false;

      const base = 4.0;             // base speed
      const paceBonus = p.pace * 0.8;     // -1.6 .. +1.6
      const staminaFactor = 0.5 + 0.5 * (p.stamina / 100); // 0.5..1.0
      const jumpPenalty = p.jumping ? -1.0 : 0.0; // simple airtime penalty
      const accel = 0.15;

      // simple integrate
      p.v += accel;
      let speed = base + paceBonus;
      speed *= staminaFactor;
      speed += jumpPenalty;
      speed = Math.max(0, speed);

      // friction
      p.v = 0.9 * p.v + 0.1 * speed;

      // advance
      p.x += p.v;

      // stamina drain
      const drain = 0.06 + Math.max(0, p.pace) * 0.05 + (p.jumping ? 0.4 : 0);
      p.stamina = Math.max(0, p.stamina - drain);

      // landing
      p.jumping = false;

      // finish check
      if (p.x >= TRACK_LEN) {
        p.finished = true;
        p.finishTime = Date.now() - r.startAt;
      }
    }

    const snapshot = {
      code,
      status: r.status,
      trackLen: TRACK_LEN,
      lanes: LANES,
      players: [...r.players.entries()].map(([id, p]) => ({
        id, name: p.name, lane: p.lane, x: Math.min(p.x, TRACK_LEN),
        v: p.v, stamina: p.stamina, whipsLeft: p.whipsLeft, finished: p.finished, finishTime: p.finishTime
      }))
    };

    io.to(code).emit('state', snapshot);

    if (allFinished) {
      r.status = 'ended';
      io.to(code).emit('ended', {
        results: snapshot.players.sort((a,b)=> (a.finishTime??1e12) - (b.finishTime??1e12)).map((p,i)=>({
          name: p.name, place: i+1, timeMs: p.finishTime
        }))
      });
    }
  }
}, 1000 / TICK_HZ);

const PORT = process.env.PORT || 3000;
httpServer.listen(PORT, () => console.log('Server listening on', PORT));
